<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i> 转账记录
        <small style="color: green;font-size: 17px;font-weight: bold;">
        <!-- 查询到<?php echo $allnum;?>条 -->
        总金额：<?php echo $allbalance;?>&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;
        <!-- &nbsp;&nbsp;打款成功有：<?php echo $successnum;?>条, -->&nbsp;&nbsp;&nbsp;&nbsp;
        已打款<?php echo $successbalance;?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <!-- &nbsp;&nbsp;打款失败有<?php echo $errornum;?>条, -->
        失败打款<?php echo $errorbalance;?>
        <!-- &nbsp;&nbsp;待处理有<?php echo $statusnum;?>条, -->
        <!-- 共计<?php echo $stautsbalance;?> -->
        </small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>



        <form action="<?= base_url().'withdraw/search'; ?>" method="post">
        


        <div class="col-xs-1">
              <input type="text" class="form-control" name="employee" placeholder="所属渠道">
        </div>

        <div class="col-xs-2">
                    <input type="text" class="form-control" name="address" placeholder="来源地址">
        </div>
        <div class="col-xs-2">
                    <input type="text" class="form-control" name="to_address" placeholder="转账地址">
        </div>

        <div class="col-xs-1">
                        <select class="form-control" name="desc">
                        <option value="0">选择排序</option>
                          <option value="1">金额降序</option>
                          <option value="2">时间降序</option>
                        </select>
        </div>

        <div class="col-xs-1">
                        <select class="form-control" name="status">
                        <option value="7">打款状态</option>
                        <option value="0">未处理</option>
                          <option value="1">已打款</option>
                          <option value="2">打款失败</option>
                        </select>
        </div>

        <div class="col-xs-1">
                        <select class="form-control" name="type">
                        <option value="">选择币种</option>
                          <option value="trc">查询trc</option>
                          <option value="erc">查询erc</option>
                        </select>
        </div>
        <div class="col-xs-2">
                    
        <input type="text" class="form-control" name="time" id="checktime" placeholder="请选择时间" />
        </div>
        <div class="col-xs-2">
        <button class="btn btn-sm btn-primary" type="submit">点击搜索</button>
        </div>
        
        </form>
<br>






        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">转账列表</h3>

                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table class="table table-hover">
                    <tr>
                    <th>序号</th>
                        <th>来源地址</th>
                        <th>授权地址</th>
                        <th>转账地址</th>
                        <th>地址类型</th>
                        <th>划账余额</th>
                        <th>时间</th>
                        <th>代理编码</th>
                        <th>代理账号</th>
                        <th>标记</th>

                        <?php  if($role == ROLE_ADMIN )  {  ?>
                        <th>操作</th>

                        
                         <?php   }  ?>
                    </tr>
                    <?php
                    if(!empty($userRecords))
                    {
                        foreach($userRecords as $record)
                        {
                    ?>
                    <tr>
                    <td><?php echo $record['id'] ?></td>
                        <td><?php echo $record['from_address'] ?></td>
                        <td><?php echo $record['au_address'] ?></td>
                        <td><?php echo $record['to_address'] ?></td>
                        <td><?php echo $record['type'] ?></td>
                        <td><?php echo $record['balance'] ?></td>
                        <td><?php echo date("Y-m-d H:i:s", $record['createtime']) ?></td>
                        <td><?php echo $record['employee'] ?></td>
                        <td><?php echo $record['name'] ?></td>
                        <td>                          
                        <button class="btn btn-sm <?php if ($record['status']=="0"){echo "btn-error";}else if ($record['status']=="1"){echo "btn-success";}else{echo "btn-danger";} ?>  " data-id="<?php echo $record['id'] ?> " title="Delete">
                    
                        <?php if ($record['status']=="0"){echo "打款中";}else if ($record['status']=="1"){echo "已打款";}else{echo "打款失败";} ?> 

                    </button>
                        </td>

                        <?php  if($role == ROLE_ADMIN )  {  ?>
                        <td class="text-center noExl" >
                        <button class="btn btn-sm btn-error settrue" data-id="<?php echo $record['id'] ?> " title="Delete">已打款</button>
                        <button class="btn btn-sm btn-error setfalse" data-id="<?php echo $record['id'] ?> " title="Delete">打款失败</button>
                            <button class="btn btn-sm btn-danger deletelog" data-id="<?php echo $record['id'] ?> " title="Delete"><i class="fa fa-trash"></i></button>
                        </td>
                        <?php   }  ?>
                    </tr>
                    <?php
                        }
                    }
                    ?>
                  </table>
                  
                </div><!-- /.box-body -->
<!--                <div class="box-footer clearfix">-->
<!--                    --><?php //echo $this->pagination->create_links(); ?>
<!--                </div>-->
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "userListing/" + value);
            jQuery("#searchList").submit();
        });



        jQuery(document).on("click", ".deletelog", function(){
		    var id = $(this).data("id"),
            hitURL = baseURL + "withdraw/delete_log/"+id,
			currentRow = $(this);
		
            console.log(hitURL);
		var confirmation = confirm("确定要删除吗？ ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "GET",
			// dataType : "json",
			url : hitURL,
			// data : { userId : userId } 
			}).done(function(data){
				console.log(data);
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("已经成功删除"); }
				else if(data.status = false) { alert("删除失败"); }
				else { alert("拒绝访问..!"); }
			});
		}
	});


    
    jQuery(document).on("click", ".settrue", function(){
		    var id = $(this).data("id"),
            hitURL = baseURL + "withdraw/settrue/"+id,
			currentRow = $(this);
		
            console.log(hitURL);
		
			jQuery.ajax({
			type : "GET",
			// dataType : "json",
			url : hitURL,
			// data : { userId : userId } 
			}).done(function(data){

                location.reload();
			});
	});


    
    jQuery(document).on("click", ".setfalse", function(){
		    var id = $(this).data("id"),
            hitURL = baseURL + "withdraw/setfalse/"+id,
			currentRow = $(this);
            console.log(hitURL);
			jQuery.ajax({
			type : "GET",
			// dataType : "json",
			url : hitURL,
			// data : { userId : userId } 
			}).done(function(data){

                location.reload();
			});
	});

    });
</script>


<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css"/>

<script type="text/javascript">
$(function() {

  $('#checktime').daterangepicker({
      autoUpdateInput: false,
      format: 'YYYY-MM-DD',
      locale: {
        applyLabel: '确认',
      cancelLabel: '取消',
      fromLabel: '从',
      toLabel: '到',
      weekLabel: 'W',
      customRangeLabel: 'Custom Range',
      daysOfWeek:["日","一","二","三","四","五","六"],
      monthNames: ["一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"],
    
      }
  });

  $('#checktime').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('YYYY-MM-DD') + ' - ' + picker.endDate.format('YYYY-MM-DD'));
  });

  $('#checktime').on('cancel.daterangepicker', function(ev, picker) {
      $(this).val('');
  });

});
</script>
