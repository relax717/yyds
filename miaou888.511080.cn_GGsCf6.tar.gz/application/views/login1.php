<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <title>管理后台登录</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="<?php echo base_url(); ?>assets/login/css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <div class="dowebok">
        <div class="container">
            <div class="left">
                <div class="login">欢迎登录</div>
                <?php $this->load->helper('form'); ?>
            </div>
            <?php
        $this->load->helper('form');
        $error = $this->session->flashdata('error');
        if($error)
        {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error; ?>                    
            </div>
        <?php }
        $success = $this->session->flashdata('success');
        if($success)
        {
            ?>
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $success; ?>                    
            </div>
        <?php } ?>
            <div class="right">
                <svg viewBox="0 0 320 300">
                    <defs>
                        <linearGradient inkscape:collect="always" id="linearGradient" x1="13" y1="193.49992" x2="307"
                            y2="193.49992" gradientUnits="userSpaceOnUse">
                            <stop style="stop-color:#ff00ff;" offset="0" id="stop876" />
                            <stop style="stop-color:#ff0000;" offset="1" id="stop878" />
                        </linearGradient>
                    </defs>
                    <path d="m 40,120.00016 239.99984,-3.2e-4 c 0,0 24.99263,0.79932 25.00016,35.00016 0.008,34.20084 -25.00016,35 -25.00016,35 h -239.99984 c 0,-0.0205 -25,4.01348 -25,38.5 0,34.48652 25,38.5 25,38.5 h 215 c 0,0 20,-0.99604 20,-25 0,-24.00396 -20,-25 -20,-25 h -190 c 0,0 -20,1.71033 -20,25 0,24.00396 20,25 20,25 h 168.57143" />
                </svg>
                <form action="<?php echo base_url(); ?>loginMe" method="post">
                <div class="form">
                    <label for="email">账号</label>
                    <input type="text" id="email" name="email">
                    <label for="password">密码</label>
                    <input type="password" id="password" name=password>
                    <input type="submit" id="submit" value="登陆">
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo base_url(); ?>assets/login/js/anime.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/login/js/index.js"></script>
</body>

</html>