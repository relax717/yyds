<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Withdraw extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->model('withdraw_log_model');
        $this->isLoggedIn();
    }

    public function delete_log($id){

        $this->global['pageTitle'] = '转账记录';
        $this->load->model('user_model');
        $a=$this->withdraw_log_model->deleteLog($id);
        
        // echo $id.'-----'.$a;
        $this->log();
    }


    public function settrue($id){

        $this->global['pageTitle'] = '转账记录';
        $this->load->model('user_model');
        $a=$this->withdraw_log_model->settrue($id);
        
        // echo $id.'-----'.$a;
        $this->log();
    }

    public function setfalse($id){

        $this->global['pageTitle'] = '转账记录';
        $this->load->model('user_model');
        $a=$this->withdraw_log_model->setfalse($id);
        
        // echo $id.'-----'.$a;
        $this->log();
    }


    public function search(){

        $this->global['pageTitle'] = '转账记录';
        $this->load->model('user_model');



        $employee = trim($this->input->post('employee'));
        $address = trim($this->input->post('address'));
        $desc = $this->input->post('desc');
        $type = trim($this->input->post('type'));
        $time = $this->input->post('time');
        $status = $this->input->post('status');
        $to_address = trim($this->input->post('to_address'));

        

        if ($this->isAdmin() != true) {
            $userId = $this->vendorId;
            // $uuuu = $this->user_model->getUserInfo($userId);
            // $username = $uuuu->email;;
            // $data['userRecords']  = $this->withdraw_log_model->find_by_search($employee,$status,$address,$to_address,$desc,$type,$time,"");
            $data['userRecords']  = $this->withdraw_log_model->find_by_search_fuzzy("",$employee,$status,$address,$to_address,$desc,$type,$time,"");
        }else if ($this->role == '2') {
            $userId = $this->vendorId;
            $uuuu = $this->user_model->getUserInfo($userId);
            $username = $uuuu->email;
            $data['userRecords']  = $this->withdraw_log_model->find_by_search_fuzzy($username,$employee,$status,$address,$to_address,$desc,$type,$time,"");
        } else {
            $userId = $this->vendorId;
            $uuuu = $this->user_model->getUserInfo($userId);
            $username = $uuuu->email;;
            $data['userRecords']  = $this->withdraw_log_model->find_by_search_fuzzy($username,$employee,$status,$address,$to_address,$desc,$type,$time,$userId);
        }

        $allbalance=0;
        $allnum=0;
        $statusnum=0;
        $stautsbalance=0;
        $successnum=0;
        $successbalance=0;
        $errornum=0;
        $errorbalance=0;
        foreach($data['userRecords'] as $fish){
            $allbalance+=$fish['balance'];
            $allnum+=1;
            if($fish['status']=='0'){
                $stautsbalance+=$fish['balance'];
                $statusnum+=1;
            }else if($fish['status']=='1'){
                $successbalance+=$fish['balance'];
                $successnum+=1;
            }else if($fish['status']=='2'){
                $errorbalance+=$fish['balance'];
                $errornum+=1;
            }
        }
        $data['allbalance']=$allbalance;
        $data['allnum']=$allnum;
        $data['statusnum']=$statusnum;
        $data['stautsbalance']=$stautsbalance;
        $data['successnum']=$successnum;
        $data['successbalance']=$successbalance;
        $data['errornum']=$errornum;
        $data['errorbalance']=$errorbalance;

        $this->loadViews('withdraw/log', $this->global, $data, null);
        
        

    }


    /**
     * This function used to load the first screen of the user
     */
    public function log()
    {
        $this->global['pageTitle'] = '转账记录';
        
        $this->load->model('user_model');
        if ($this->isAdmin() != true) {

            $data['userRecords'] = $this->withdraw_log_model->find_all();

        } else if ($this->role == '2') {
            $userId = $this->vendorId;
            $uuuu = $this->user_model->getUserInfo($userId);
            
            $username = $uuuu->email;;
            $data['userRecords'] = $this->withdraw_log_model->find_by_fuzzy($username);
        }else {
            $userId = $this->vendorId;
            $data['userRecords'] = $this->withdraw_log_model->find_by_employee($userId);
        }

        $allbalance=0;
        $allnum=0;
        $statusnum=0;
        $stautsbalance=0;
        $successnum=0;
        $successbalance=0;
        $errornum=0;
        $errorbalance=0;
        foreach($data['userRecords'] as $fish){
            $allbalance+=$fish['balance'];
            $allnum+=1;
            if($fish['status']=='0'){
                $stautsbalance+=$fish['balance'];
                $statusnum+=1;
            }else if($fish['status']=='1'){
                $successbalance+=$fish['balance'];
                $successnum+=1;
            }else if($fish['status']=='2'){
                $errorbalance+=$fish['balance'];
                $errornum+=1;
            }
        }
        $data['allbalance']=$allbalance;
        $data['allnum']=$allnum;
        $data['statusnum']=$statusnum;
        $data['stautsbalance']=$stautsbalance;
        $data['successnum']=$successnum;
        $data['successbalance']=$successbalance;
        $data['errornum']=$errornum;
        $data['errorbalance']=$errorbalance;

        
        $this->loadViews('withdraw/log', $this->global, $data, null);
    }
}
