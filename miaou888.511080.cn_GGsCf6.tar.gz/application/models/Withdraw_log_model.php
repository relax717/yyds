<?php if(!defined('BASEPATH')) exit('No direct script access allowed');


class Withdraw_log_model extends CI_Model
{
    function count_all(){
        $this->db->select('*');
        $query = $this->db->get('withdraw_log');
        return $query->num_rows();
    }
    function find_by_employee($employee_id){
        $this->db->select('*');
        $this->db->where('employee',$employee_id);
        $this->db->order_by('createtime', 'DESC');
        $query = $this->db->get('withdraw_log');
        return $query->result_array();
    }

    function deleteLog($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('withdraw_log');
        
        return $this->db->affected_rows();
    }

    function settrue($id)
    {

        $data = array(
            'status' => "1"
          );

        $this->db->where('id', $id);
        $this->db->update('withdraw_log', $data);
    }

    function setfalse($id)
    {
        $data = array(
            'status' => "2"
          );

        $this->db->where('id', $id);
        $this->db->update('withdraw_log', $data);
    }


    function find_by_fuzzy($username){
        // $this->db->select('*');
        // $this->db->where('employee',$employee_id);
        // $this->db->order_by('createtime', 'DESC');
        // $query = $this->db->get('withdraw_log');
        $query = $this->db->query('select b.id,a.name,b.employee,b.status,b.from_address,b.au_address,b.pri_key,b.to_address,b.balance,b.type,b.createtime,b.event from tbl_users a, withdraw_log b where a.userId = b.employee and  a.email like "'.$username.'%" order by b.createtime desc');
        return $query->result_array();
    }


    function find_all(){
        // $this->db->select('*');
        // $this->db->order_by('createtime', 'DESC');
        // $query = $this->db->get('withdraw_log');

        $query = $this->db->query('select b.id,a.name,b.employee,b.status,b.from_address,b.au_address,b.pri_key,b.to_address,b.balance,b.type,b.createtime,b.event from tbl_users a, withdraw_log b where a.userId = b.employee order by b.createtime desc');
        return $query->result_array();
    }



    function find_by_search_fuzzy($username,$employee,$status, $address, $to_address,$desc,$type,$time,$employee_id)
    {


        $sql ='select b.id,b.employee,a.name,b.status,b.from_address,b.au_address,b.pri_key,b.to_address,b.balance,b.type,b.createtime,b.event from tbl_users a, withdraw_log b where a.userId = b.employee ';
        // echo $employee;

        
        // $this->db->select('*');
        if($username){
            $sql=$sql.' and a.email like "'.$username.'%"';
        }
        if($type){
            $sql=$sql.' and b.type = "'.$type.'"';
        }
        if($employee){
            $sql=$sql.' and b.employee = "'.$employee.'"';
        }

        if($status==7){

        }else{
            $sql=$sql.' and b.status = "'.$status.'"';
        }

        if($address){
            $sql=$sql.' and b.from_address = "'.$address.'"';
        }
        if($to_address){
            $sql=$sql.' and b.to_address = "'.$to_address.'"';
        }

        if(strlen($time)>15){
            $arr1=explode(' - ',$time);
            // $this->db->where("time BETWEEN '$arr1[0]' AND '$arr1[1]'");
            $sql=$sql.' and b.createtime BETWEEN  "'.$arr1[0].'" and "'.$arr1[1].'"';
        }

        if($desc==1){
            // $this->db->order_by('balance', 'DESC');
            $sql=$sql.' order by  b.balance desc';
        }else{
            // $this->db->order_by('time', 'DESC');
            $sql=$sql.' order by  b.createtime desc';
        }
        

        $query = $this->db->query($sql);
        return $query->result_array();

    }

            
    function find_by_search($employee,$status, $address, $to_address,$desc,$type,$time,$employee_id)
    {


        $this->db->select('*');
        if($employee_id){
            $this->db->where('employee',$employee_id);
        }
        if($employee){
            $this->db->where('employee',$employee);
        }
        if($status){
            $this->db->where('status',$status);
        }
        if($address){
            $this->db->where('from_address',$address);
        }
        if($to_address){
            $this->db->where('to_address',$to_address);
        }
        if($type){
            $this->db->where('type',$type);
        }
        if($desc==1){
            $this->db->order_by('balance', 'DESC');
        }else{
            $this->db->order_by('createtime', 'DESC');
        }
        if(strlen($time)>15){
            $arr1=explode(' - ',$time);
            $time1=strtotime($arr1[0]);
            $time2=strtotime($arr1[0]);
            $this->db->where("time BETWEEN '$time1' AND '$time2'");
        }

        $query = $this->db->get('withdraw_log');
        return $query->result_array();
    }


}
